
<div class="modal hide fade" id="a<?php echo $id; ?>">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">?</button>

    </div>
    <div class="modal-body">
        <div class="alert alert-info">
            <h2>Add what?</h2>
        </div>
        <center>                           
            <p><a href="add_leave_non.php<?php echo '?id='.$id; ?>" class="btn btn-large"><i class="icon-file icon-large"></i>&nbsp;Add Leave Credits</a> </p>
            <p><a href="add_service.php<?php echo '?id='.$id; ?>" class="btn btn-success btn-large"><i class="icon-file icon-large"></i>&nbsp;Service Record</a></p> 
        </center>
    </div>
    <div class="modal-footer">
        <a href="#" class="btn" data-dismiss="modal">Close</a>

    </div>
                                </div>