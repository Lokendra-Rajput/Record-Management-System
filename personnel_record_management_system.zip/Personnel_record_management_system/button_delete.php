     <div class="modal hide fade" id="d<?php echo $id; ?>">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">�</button>
                                        <h3> </h3>
                                    </div>
                                    <div class="modal-body">
                                        <div class="alert alert-error">
                                            <p><font color="gray">Are You Sure you Want to Delete This User?</font></p>
                                        </div>
                                        <center>
                                        <a href="#" class="btn btn-large btn-success" data-dismiss="modal">  <i class="icon-remove icon-large"></i>&nbsp;&nbsp;No</a>
                                        <a href="delete_emp.php<?php echo '?id='.$id; ?>" class="btn btn-danger btn-large"> <i class="icon-ok icon-large"></i>&nbsp;&nbsp;Yes</a>
                                        </center>
                                    </div>
                                    <div class="modal-footer">
                                                                          
                                    </div>
                                </div>