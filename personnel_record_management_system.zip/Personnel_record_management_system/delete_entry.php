<?php
  include('dbcon.php');
  
  $get_id=$_GET['id'];
  
  
  mysql_query("delete from school where school_id='$get_id'")or die(mysql_error());
  
  header('location:entry.php');
  
  
?>
