
  <?php
include('dbcon.php');

$id=$_POST['id'];


mysql_query("delete from leave_record where leave_id='$id'")or die(mysql_error());
  
?>


