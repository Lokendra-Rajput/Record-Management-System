
  <?php
include('dbcon.php');

$id=$_POST['id'];


mysql_query("delete from service_record where service_record_id='$id'")or die(mysql_error());
  
?>

