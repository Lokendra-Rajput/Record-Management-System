
  <?php
include('dbcon.php');

$id=$_POST['id'];


mysql_query("delete from service_credits where service_credits_id='$id'")or die(mysql_error());
  
?>

