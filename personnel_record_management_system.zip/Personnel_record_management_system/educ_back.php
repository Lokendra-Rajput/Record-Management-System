    <div class="row-fluid">
    <div class="span12">

    <div class="row-fluid">
    <div class="span6">
    
                           <div class="form-horizontal">
                           <legend>Elementary Level</legend>
                    <fieldset>
                        <div class="control-group">
                            <label class="control-label" for="input01">Name of School:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Name of School (Write in full)">

                            </div>     
                        </div>

                       


                        <div class="control-group">
                            <label class="control-label" for="input01">Degree Course:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Degree Course (write in full)">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">Year Graduated:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Year Graduated (if graduated)">

                            </div>     
                        </div>


                        <div class="control-group">
                            <label class="control-label" for="input01">Highest Grade/Level/Units Earned:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="(if not graduated)">

                            </div>     
                        </div>


                        <div class="control-group">
                            <label class="control-label" for="input01">Inclusive Dates of Attendance:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Telephone NO">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">Scholarship/Academic Honors Received:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Scholarship/Academic Honors Received">

                            </div>     
                        </div>
                    </fieldset>
                </div>

                
                

    
    </div>
    <div class="span6">
    
                <div class="form-horizontal">
                           <legend>Secondary Level</legend>
                    <fieldset>
                        <div class="control-group">
                            <label class="control-label" for="input01">Name of School:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Name of School (Write in full)">

                            </div>     
                        </div>

                       


                        <div class="control-group">
                            <label class="control-label" for="input01">Degree Course:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Degree Course (write in full)">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">Year Graduated:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Year Graduated (if graduated)">

                            </div>     
                        </div>


                        <div class="control-group">
                            <label class="control-label" for="input01">Highest Grade/Level/Units Earned:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="(if not graduated)">

                            </div>     
                        </div>


                        <div class="control-group">
                            <label class="control-label" for="input01">Inclusive Dates of Attendance:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Telephone NO">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">Scholarship/Academic Honors Received:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Scholarship/Academic Honors Received">

                            </div>     
                        </div>
                    </fieldset>
                </div>

    </div>
    </div>
    </div>
    </div>


    
     <div class="row-fluid">
    <div class="span12">

    <div class="row-fluid">
    <div class="span6">
    
                 
                        <div class="form-horizontal">
                           <legend>Vocation/ Trade Course</legend>
                    <fieldset>
                        <div class="control-group">
                            <label class="control-label" for="input01">Name of School:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Name of School (Write in full)">

                            </div>     
                        </div>

                       


                        <div class="control-group">
                            <label class="control-label" for="input01">Degree Course:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Degree Course (write in full)">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">Year Graduated:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Year Graduated (if graduated)">

                            </div>     
                        </div>


                        <div class="control-group">
                            <label class="control-label" for="input01">Highest Grade/Level/Units Earned:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="(if not graduated)">

                            </div>     
                        </div>


                        <div class="control-group">
                            <label class="control-label" for="input01">Inclusive Dates of Attendance:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Telephone NO">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">Scholarship/Academic Honors Received:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Scholarship/Academic Honors Received">

                            </div>     
                        </div>
                    </fieldset>
                </div> 
                

    
    </div>
    <div class="span6">
            <div class="form-horizontal">
                           <legend>College</legend>
                    <fieldset>
                        <div class="control-group">
                            <label class="control-label" for="input01">Name of School:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Name of School (Write in full)">

                            </div>     
                        </div>

                       


                        <div class="control-group">
                            <label class="control-label" for="input01">Degree Course:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Degree Course (write in full)">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">Year Graduated:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Year Graduated (if graduated)">

                            </div>     
                        </div>


                        <div class="control-group">
                            <label class="control-label" for="input01">Highest Grade/Level/Units Earned:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="(if not graduated)">

                            </div>     
                        </div>


                        <div class="control-group">
                            <label class="control-label" for="input01">Inclusive Dates of Attendance:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Telephone NO">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">Scholarship/Academic Honors Received:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Scholarship/Academic Honors Received">

                            </div>     
                        </div>
                    </fieldset>
                </div> 
    </div>
    </div>
    </div>
    </div>


    
 