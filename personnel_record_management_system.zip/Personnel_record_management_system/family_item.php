                <div class="row-fluid">
    <div class="span12">

    <div class="row-fluid">
    <div class="span6">
    
           
            
               <div class="form-horizontal">
                    <fieldset>
                    
                    
                  
                    
                        <div class="control-group">
                            <label class="control-label" for="input01">Spouse's Surname:</label>
                            <div class="controls">
                                <input type="text"  name="Birthdate" class="Birthdate" placeholder="Spouse's Surname">

                            </div>     
                        </div>

                        <div class="control-group">
                            <label class="control-label" for="input01">FirstName:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="FirstName">

                            </div>     
                        </div>



                      

                        <div class="control-group">
                            <label class="control-label" for="input01">Middle Name:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Civil Status">

                            </div>     
                        </div>

                        <div class="control-group">
                            <label class="control-label" for="input01">Occupation:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Occupation">

                            </div>     
                        </div>

                               <div class="control-group">
                            <label class="control-label" for="input01">Employer/BUS Name:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Employer/BUS Name">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">Business Address:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Business Address">

                            </div>     
                        </div>

                        <div class="control-group">
                            <label class="control-label" for="input01">Telephone No:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Telephone No">

                            </div>     
                        </div>

                      

                    </fieldset>
                </div>

    
    
    </div>
    <div class="span6">
    
      <div class="form-horizontal">
                    <fieldset>
                    
                    
                  
                    
                        <div class="control-group">
                            <label class="control-label" for="input01">Father's Surname:</label>
                            <div class="controls">
                                <input type="text"  name="Birthdate" class="Birthdate" placeholder="Spouse's Surname">

                            </div>     
                        </div>

                        <div class="control-group">
                            <label class="control-label" for="input01">FirstName:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="FirstName">

                            </div>     
                        </div>



                      

                        <div class="control-group">
                            <label class="control-label" for="input01">Middle Name:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Civil Status">

                            </div>     
                        </div>

                        <div class="control-group">
                            <label class="control-label" for="input01">Mother Maiden Name:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Mother Maiden Name">

                            </div>     
                        </div>

                               <div class="control-group">
                            <label class="control-label" for="input01">Surname:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="Surname">

                            </div>     
                        </div>



                        <div class="control-group">
                            <label class="control-label" for="input01">FirstName:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="FirstName">

                            </div>     
                        </div>

                        <div class="control-group">
                            <label class="control-label" for="input01">MiddleName:</label>
                            <div class="controls">
                                <input type="text" class="input-xlarge" id="input01" placeholder="MiddleName">

                            </div>     
                        </div>

                      

                    </fieldset>
                </div>
    
    
    </div>
    </div>
    </div>
    </div>


           