	  <hr>

      <footer>
        <div class="pull-right"><a  data-toggle="modal" href="#developer" class="label label-info">Developers</a></div>
  
  
  
  <div class="modal hide fade" id="developer">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">�</button>
        <h3> </h3>
    </div>
    <div class="modal-body">
           <div class="alert alert-info">
  Developers
    </div>
<div class="row">
  <div class="span6">
    
    <div class="row">
      <div class="span3">Eunice F. Bautista</div>
      <div class="span3"><img src="img/bok.jpg" width="200" height="150"></div>
    </div>
	
	 <div class="row">
      <div class="span3">Welmarie Ann N. Gamboa</div>
      <div class="span3"><img src="img/lai.jpg" width="200" height="150"></div>
    </div>
	
	 <div class="row">
      <div class="span3">Kring Martinez Delez</div>
      <div class="span3"><img src="img/143.jpg" width="200" height="150"></div>
    </div>
	
  </div>
</div>
	
	
    </div>
    <div class="modal-footer">
        <a href="#" class="btn" data-dismiss="modal">Close</a>
     
    </div>
        </div>
  
  
        <p>Copyright &copy; DEPED Silay City All rights reserved.</p>
      </footer>