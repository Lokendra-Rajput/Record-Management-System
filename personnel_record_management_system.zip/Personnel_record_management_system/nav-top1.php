	<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	<div class="container">
	     
		<a class="brand">
		<img src="img/logo.png" width="200" height="58">
 	</a> 
	<a class="brand">
	 <h2>Personnel Record Management System</h2>
	 <div class="chmsc_nav"><font size="4" color="white">Department of Education Silay City</font></div>
 	</a>


	</div>
	</div>
	</div>